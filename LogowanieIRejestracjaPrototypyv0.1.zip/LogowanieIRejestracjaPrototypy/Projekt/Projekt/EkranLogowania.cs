namespace Projekt
{
    public partial class EkranLogowania : Form
    {
        public EkranLogowania()
        {
            InitializeComponent();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            EkranRejestracji rejestracja = new EkranRejestracji();
            rejestracja.Show();

            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
