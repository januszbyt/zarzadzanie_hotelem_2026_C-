﻿// ConsoleApplication1.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <math.h>
#include <cmath>
using namespace std;
//Zadanie.3
//int main()
//{
//	int liczA;
//	int liczB;
//	
//	cout << "Podaj I liczbe:";
//	cin >> liczA;
//	cout << "Podaj II liczbe:";
//	cin >> liczB;
//
//	int suma = liczA + liczB;
//	int roznica = liczA - liczB;
//
//	cout << "Suma:" << suma << endl;
//	cout << "Roznica:" << roznica << endl;
//
//}
//Zadanie.2
//int main() {
//	double podstawa,wynik;
//	int wykladnik;
//
//	cout << "Podaj podstawe:" << endl;
//	cin >> podstawa;
//	cout << "Podaj wykladnik:" << endl;
//	cin >> wykladnik;
//
//	wynik = pow(podstawa, wykladnik);
//
//	cout << "Wynik potegowania to:" << wynik << endl;
//
//}
//Zadanie 1
//bool sprawdzliczbe(int liczba) {
//	if (liczba < 10 || liczba > 99) {
//		return false;
//	}
//
//	int cyfra1 = liczba / 10;
//	int cyfra2 = liczba % 10;
//
//	return (cyfra1 % 2 != 0 && cyfra2 % 2 != 0) || (cyfra1 + cyfra2 == 6);
//}
//int main() {
//	int liczba;
//	cout << "Podaj liczbe dwucyfrowa:";
//	cin >> liczba;
//	if (sprawdzliczbe(liczba)) {
//		cout << "OK" << endl;
//	}
//	else {
//		cout << "Nie" << endl;
//	}
//
//	return 0;
//}


// Uruchomienie programu: Ctrl + F5 lub menu Debugowanie > Uruchom bez debugowania
// Debugowanie programu: F5 lub menu Debugowanie > Rozpocznij debugowanie

// Porady dotyczące rozpoczynania pracy:
//   1. Użyj okna Eksploratora rozwiązań, aby dodać pliki i zarządzać nimi
//   2. Użyj okna programu Team Explorer, aby nawiązać połączenie z kontrolą źródła
//   3. Użyj okna Dane wyjściowe, aby sprawdzić dane wyjściowe kompilacji i inne komunikaty
//   4. Użyj okna Lista błędów, aby zobaczyć błędy
//   5. Wybierz pozycję Projekt > Dodaj nowy element, aby utworzyć nowe pliki kodu, lub wybierz pozycję Projekt > Dodaj istniejący element, aby dodać istniejące pliku kodu do projektu
//   6. Aby w przyszłości ponownie otworzyć ten projekt, przejdź do pozycji Plik > Otwórz > Projekt i wybierz plik sln
