﻿namespace Formularz_nowej_rezerwacji
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            label9 = new Label();
            textBox5 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Noto Naskh Arabic", 21.7499981F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 238);
            label1.Location = new Point(232, 9);
            label1.Name = "label1";
            label1.Size = new Size(375, 59);
            label1.TabIndex = 0;
            label1.Text = "Dodaj Nową Rezerwacje";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 238);
            label2.Location = new Point(36, 79);
            label2.Name = "label2";
            label2.Size = new Size(152, 21);
            label2.TabIndex = 1;
            label2.Text = "Wypełnij formularz:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(136, 109);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(136, 149);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(136, 271);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(136, 307);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 109);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 6;
            label3.Text = "Nazwisko";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(22, 149);
            label4.Name = "label4";
            label4.Size = new Size(30, 15);
            label4.TabIndex = 7;
            label4.Text = "Imie";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 271);
            label5.Name = "label5";
            label5.Size = new Size(74, 15);
            label5.TabIndex = 8;
            label5.Text = "Email Gościa";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(22, 310);
            label6.Name = "label6";
            label6.Size = new Size(69, 15);
            label6.TabIndex = 9;
            label6.Text = "Nr Telefonu";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(22, 193);
            label7.Name = "label7";
            label7.Size = new Size(144, 15);
            label7.TabIndex = 10;
            label7.Text = "Planowana data przyjazdu";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(22, 230);
            label8.Name = "label8";
            label8.Size = new Size(136, 15);
            label8.TabIndex = 11;
            label8.Text = "Planowana data odjazdu";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(172, 187);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 12;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(164, 224);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(200, 23);
            dateTimePicker2.TabIndex = 13;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(22, 360);
            label9.Name = "label9";
            label9.Size = new Size(130, 15);
            label9.TabIndex = 14;
            label9.Text = "Długość pobytu (Noce)";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(158, 357);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 15;
            // 
            // button1
            // 
            button1.Location = new Point(12, 403);
            button1.Name = "button1";
            button1.Size = new Size(130, 41);
            button1.TabIndex = 16;
            button1.Text = "Stwórz Rezerwacje";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(172, 403);
            button2.Name = "button2";
            button2.Size = new Size(130, 41);
            button2.TabIndex = 17;
            button2.Text = "Wyczyść formularz";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(676, 499);
            button3.Name = "button3";
            button3.Size = new Size(130, 41);
            button3.TabIndex = 18;
            button3.Text = "Powrót do Menu";
            button3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(829, 552);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox5);
            Controls.Add(label9);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label label9;
        private TextBox textBox5;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}
